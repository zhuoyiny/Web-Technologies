
var express = require('express');
var request = require("request");

var path = require("path");
var cors = require("cors");
var bodyParser = require("body-parser");
var parseString = require('xml2js').parseString;

var app = express();



app.use(express.static("./public"));
app.use(cors());

app.use(function(req, res, next) {
//	console.log(`${req.method} request for '${req.url}' - `);
	next();
});
var keyword;
var category;
var radius;
var lati;
var longi;
var address;

app.get("/app.js", function(req, res) {
	console.log(req.url);
	console.log(req.query);

	keyword = req.query.keyword;
	category = req.query.category;
	radius = req.query.radius*1609;
	lati = req.query.lat_js;
	longi = req.query.lon_js;
	address = req.query.address;

	console.log(keyword);
	console.log(category);
	console.log(radius);
	console.log(lati);
	console.log(longi);
	console.log(address);
	if(lati==""&&longi==""){
		geo_call(res);
	}else if(lati!=""&&longi!=""){
		nearby_call(res);
	}

});



app.get("/nextpage", function(req, res) {
	var token = req.query.token;
	console.log(token);
	var url_nextpage = "https://maps.googleapis.com/maps/api/place/nearbysearch/json?pagetoken="+token+"&key=AIzaSyBbOgCGopbCyS-j1o95fBXGY8Oy0QnulAM";
	console.log(url_nextpage);


	var latdes_arr = [];
	var londes_arr = [];
	var icon_arr = [];
	var name_arr = [];
	var vicinity_arr = [];
	var placeid_arr = [];

	request.get({
		url: url_nextpage,
		json: true,
		headers: {'User-Agent': 'request'}
	}, function(err, response, json_data) {

		if (err) {
			console.log('Error:', err);
		} else if (res.statusCode !== 200) {
			res.setHeader('Content-Type', 'application/json');
			res.header("Access-Control-Allow-Origin", "*");
			res.header("Access-Control-Allow-Headers", "X-Requested-With");
			console.log('Status:', response.statusCode);
		} else {
		  // data is already parsed as JSON:
			console.log(json_data);
			res.setHeader('content-type', 'application/json');
			//res.json(json_data);
			var token = json_data.next_page_token;

			var len = json_data.results.length;
			console.log(len);
			for(var i = 0; i<len; i++){
				var latdes = json_data.results[i].geometry.location.lat;
				console.log(latdes);
				var londes = json_data.results[i].geometry.location.lng;
				var icon = json_data.results[i].icon;
				var name = json_data.results[i].name;
				var vicinity = json_data.results[i].vicinity;
				var placeid = json_data.results[i].place_id;
				latdes_arr.push(latdes);
				londes_arr.push(londes);
				icon_arr.push(icon);
				name_arr.push(name);
				vicinity_arr.push(vicinity);
				placeid_arr.push(placeid);
			}
			console.log(latdes_arr);
			console.log(londes_arr);
			console.log(icon_arr);
			console.log(name_arr);
			console.log(vicinity_arr);
			console.log(placeid_arr);
			console.log("999999");
			var data_arr = [lati, longi, icon_arr, name_arr, vicinity_arr, placeid_arr, latdes_arr, londes_arr, token];
			res.json(data_arr);
		}
	});





});


app.get("/map", function(req, res) {
	var from = req.query.from;
	var url_geocode = "https://maps.googleapis.com/maps/api/geocode/json?address=" +from+"&key=AIzaSyBbOgCGopbCyS-j1o95fBXGY8Oy0QnulAM";
	console.log(url_geocode);

	request.get({
		url: url_geocode,
		json: true,
		headers: {'User-Agent': 'request'}
	}, function(err, response, data) {

		if (err) {
			console.log('Error:', err);
		} else if (res.statusCode !== 200) {
			//res.setHeader('Content-Type', 'application/json');
			// res.header("Access-Control-Allow-Origin", "*");
			// res.header("Access-Control-Allow-Headers", "X-Requested-With");
			console.log('Status:', response.statusCode);
			console.log('     '+res.statusCode);
		} else {
		  // data is already parsed as JSON:
		  console.log("123456781234");
			console.log(data);
			//res.setHeader('content-type', 'application/json');
			//res.json(data);
			lati = data.results[0].geometry.location.lat;
			longi = data.results[0].geometry.location.lng;
			console.log(lati);
			console.log(longi);
			var data_arr = [lati, longi];
			res.json(data_arr);
		}
	});

});



app.get("/information", function(req, res) {
	var place_id = req.query.place_id;
	var url_info = "https://maps.googleapis.com/maps/api/place/details/json?placeid="+place_id+"&key=AIzaSyBbOgCGopbCyS-j1o95fBXGY8Oy0QnulAM";

	console.log(url_info);

	request.get({
		url: url_info,
		json: true,
		headers: {'User-Agent': 'request'}
	}, function(err, response, json_data) {

		if (err) {
			console.log('Error:', err);
		} else if (res.statusCode !== 200) {
			res.setHeader('Content-Type', 'application/json');
			res.header("Access-Control-Allow-Origin", "*");
			res.header("Access-Control-Allow-Headers", "X-Requested-With");
			console.log('Status:', response.statusCode);
		} else {
		  // data is already parsed as JSON:
			console.log(json_data);
			res.setHeader('content-type', 'application/json');
			//res.json(json_data);
			var formatted_address = json_data.result.formatted_address;
			var international_phone_number = json_data.result.international_phone_number;
			var price_level = json_data.result.price_level;
			var rating = json_data.result.rating;
			var url = json_data.result.url;
			var website = json_data.result.website;
			var opening_hours = json_data.result.opening_hours;

			var utc_offset = json_data.result.utc_offset;
			var reviews = json_data.result.reviews;


			console.log(formatted_address);
			console.log(international_phone_number);
			console.log(price_level);
			console.log(rating);
			console.log(url);
			console.log(website);
			console.log(opening_hours);
			console.log(utc_offset);
			console.log(reviews);

			var data_arr = [formatted_address, international_phone_number, price_level, rating, url, website, opening_hours, utc_offset, reviews];
			res.json(data_arr);
		}
	});
});




function geo_call(res){

		var url_geocode = "https://maps.googleapis.com/maps/api/geocode/json?address=" +address+"&key=AIzaSyBbOgCGopbCyS-j1o95fBXGY8Oy0QnulAM";
		console.log(url_geocode);

		request.get({
			url: url_geocode,
			json: true,
			headers: {'User-Agent': 'request'}
		}, function(err, response, data) {

			if (err) {
				console.log('Error:', err);
			} else if (res.statusCode !== 200) {
				//res.setHeader('Content-Type', 'application/json');
				// res.header("Access-Control-Allow-Origin", "*");
				// res.header("Access-Control-Allow-Headers", "X-Requested-With");
				console.log('Status:', response.statusCode);
				console.log('     '+res.statusCode);
			} else {
			  // data is already parsed as JSON:
			  console.log("123456781234");
				console.log(data);
				//res.setHeader('content-type', 'application/json');
				//res.json(data);
				lati = data.results[0].geometry.location.lat;
				longi = data.results[0].geometry.location.lng;
				console.log(lati);
				console.log(longi);
				nearby_call(res);
			}
		});

}



function nearby_call(res){
	var url_nearsearch ="https://maps.googleapis.com/maps/api/place/nearbysearch/json?location="+lati+","+longi+"&radius="+radius+"&type="+category+"&keyword="+keyword+"&key=AIzaSyB1iP7hvJJ7ISTIhh2UzEiV5Jy5bnbyrf4";
	console.log(url_nearsearch);
	var latdes_arr = [];
	var londes_arr = [];
	var icon_arr = [];
	var name_arr = [];
	var vicinity_arr = [];
	var placeid_arr = [];

	request.get({
		url: url_nearsearch,
		json: true,
		headers: {'User-Agent': 'request'}
	}, function(err, response, json_data) {

		if (err) {
			console.log('Error:', err);
		} else if (res.statusCode !== 200) {
			res.setHeader('Content-Type', 'application/json');
			res.header("Access-Control-Allow-Origin", "*");
			res.header("Access-Control-Allow-Headers", "X-Requested-With");
			console.log('Status:', response.statusCode);
		} else {
		  // data is already parsed as JSON:
			console.log(json_data);
			res.setHeader('content-type', 'application/json');
			//res.json(json_data);
			var token = json_data.next_page_token;

			var len = json_data.results.length;
			console.log(len);
			for(var i = 0; i<len; i++){
				var latdes = json_data.results[i].geometry.location.lat;
				console.log(latdes);
				var londes = json_data.results[i].geometry.location.lng;
				var icon = json_data.results[i].icon;
				var name = json_data.results[i].name;
				var vicinity = json_data.results[i].vicinity;
				var placeid = json_data.results[i].place_id;
				latdes_arr.push(latdes);
				londes_arr.push(londes);
				icon_arr.push(icon);
				name_arr.push(name);
				vicinity_arr.push(vicinity);
				placeid_arr.push(placeid);
			}
			console.log(latdes_arr);
			console.log(londes_arr);
			console.log(icon_arr);
			console.log(name_arr);
			console.log(vicinity_arr);
			console.log(placeid_arr);
			var data_arr = [lati, longi, icon_arr, name_arr, vicinity_arr, placeid_arr, latdes_arr, londes_arr, token];
			res.json(data_arr);
		}
	});
}

app.get("/yelp", function(req, res) {
	console.log(req.url);
	console.log(req.query);

	// name1 = req.query.name;
	// address3 = req.query.address;
	// city1 = req.query.city;
	// state1 = req.query.state;
	// country1 = req.query.country;

	// console.log(name1);
	// console.log(address3);
	// console.log(city1);
	// console.log(state1);
	// console.log(country1);

	var yelp = require('yelp-fusion');
	var apiKey= 'tVu1MTzQHR4y3CihQuL0JUis1I-LDphKdfu5alf41HA-ovROH-wuP0EGQE8ALB1kO8IgsIaULjWW7l3-d5ZwhxAuFePjKWbP4Q_BHL4sNL3YwqZ1rLdLhoZbPpPFWnYx';
	var client = yelp.client(apiKey);

	// matchType can be 'lookup' or 'best'
	client.businessMatch('best', {
	  name: req.query.name,
	  address1: req.query.address,
	  city: req.query.city,
	  state: req.query.state,
	  country: 'US'
	}).then(function(response) {

	  console.log(response.jsonBody);
	  if(response.jsonBody.businesses[0]!=undefined){
		  console.log(response.jsonBody.businesses[0].id);
		  res.json(response.jsonBody.businesses[0].id);
	  }else{
		  res.json('');
	  }


	}).catch(function(e) {
	  console.log(e);
	});

});




app.get("/yelpreviews", function(req, res) {
	console.log(req.url);
	console.log(req.query);

	var yelp = require('yelp-fusion');
	var apiKey= 'tVu1MTzQHR4y3CihQuL0JUis1I-LDphKdfu5alf41HA-ovROH-wuP0EGQE8ALB1kO8IgsIaULjWW7l3-d5ZwhxAuFePjKWbP4Q_BHL4sNL3YwqZ1rLdLhoZbPpPFWnYx';
	var client = yelp.client(apiKey);

	client.reviews(req.query.id).then(function(response){
	  console.log(response.jsonBody.reviews[0].text);
	   console.log(response.jsonBody.reviews);
	   res.json(response.jsonBody.reviews);


  }).catch(function(e) {
	  console.log(e);
	});


});



//
//
// app.get("/yelpreviews", function(req, res) {
// 	var id = req.query.id;
// 	var url_info = "https://api.yelp.com/v3/businesses/"+id+"/reviews";
// https://api.yelp.com/v3/businesses/"+id+"/reviews
// 	console.log(url_info);
//
// 	request.get({
// 		url: url_info,
// 		json: true,
// 		headers: {'User-Agent': 'request'}
// 	}, function(err, response, json_data) {
//
// 		if (err) {
// 			console.log('Error:', err);
// 		} else if (res.statusCode !== 200) {
// 			res.setHeader('Content-Type', 'application/json');
// 			res.header("Access-Control-Allow-Origin", "*");
// 			res.header("Access-Control-Allow-Headers", "X-Requested-With");
// 			console.log('Status:', response.statusCode);
// 		} else {
// 		  // data is already parsed as JSON:
// 			console.log(json_data);
// 			res.setHeader('content-type', 'application/json');
// 			//res.json(json_data);
// 			var formatted_address = json_data.result.formatted_address;
// 			var international_phone_number = json_data.result.international_phone_number;
// 			var price_level = json_data.result.price_level;
// 			var rating = json_data.result.rating;
// 			var url = json_data.result.url;
// 			var website = json_data.result.website;
// 			var opening_hours = json_data.result.opening_hours;
//
// 			var utc_offset = json_data.result.utc_offset;
// 			var reviews = json_data.result.reviews;
//
//
// 			console.log(formatted_address);
// 			console.log(international_phone_number);
// 			console.log(price_level);
// 			console.log(rating);
// 			console.log(url);
// 			console.log(website);
// 			console.log(opening_hours);
// 			console.log(utc_offset);
// 			console.log(reviews);
//
// 			var data_arr = [formatted_address, international_phone_number, price_level, rating, url, website, opening_hours, utc_offset, reviews];
// 			res.json(data_arr);
// 		}
// 	});
// });






if (module === require.main) {
  // Start the server
  var server = app.listen(process.env.port || 8080, function () {
    var port = server.address().port;

    console.log('App listening on port %s', port);
    console.log('Press Ctrl+C to quit.');
  });
}

module.exports = app;
